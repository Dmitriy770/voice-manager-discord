﻿using System;
using System.Security.Cryptography;
using Discord;
using Discord.WebSocket;

public class Program
{
    private DiscordSocketClient _client;
    public static Task Main(string[] args) => new Program().MainAsync();

    public async Task MainAsync()
    {
        var config = new DiscordSocketConfig
        {
            GatewayIntents = GatewayIntents.All,
            AlwaysDownloadUsers = true,
            MessageCacheSize = 100
        };
        _client = new DiscordSocketClient(config);

        _client.Log += Log;

        var token = "NzM0NzMzNjQ1OTAxNzI1NzY2.GhDDp5.bsxR2xoS0xot33Ql8GWh2cDrvuF_aNLYqc579M"; // токен

        await _client.LoginAsync(TokenType.Bot, token);
        await _client.StartAsync(); //запуск бота

        _client.MessageDeleted += MessageDeleted;
        _client.UserVoiceStateUpdated += Example;
        //_client.Spe

        await Task.Delay(-1);
    }

    private Task Log(LogMessage msg)
    {
        Console.WriteLine(msg.ToString());
        return Task.CompletedTask;
    }

    private Task MessageDeleted(Cacheable<IMessage, ulong> msg, Cacheable<IMessageChannel, ulong> channel)
    {
        Console.WriteLine(msg.Value.Content);
        Console.WriteLine(msg.Value.Channel);
        return Task.CompletedTask;
    }

    private async Task Example(SocketUser user, SocketVoiceState oldVoiceState, SocketVoiceState newVoiceState)
        {
            if(newVoiceState.VoiceChannel != null && newVoiceState.VoiceChannel.Id == 947492715321511976)
            {
                var channel = await newVoiceState.VoiceChannel.Guild.CreateVoiceChannelAsync(user.Username, x => { x.CategoryId = newVoiceState.VoiceChannel.CategoryId; });

                move_user(newVoiceState.VoiceChannel.Guild.GetUser(user.Id), (ulong)channel.Id);
                //newVoiceState.VoiceChannel.Guild.GetUser(user.Id).ModifyAsync(x => { x.ChannelId= (ulong) channel.Id; x.Nickname = "abjkba"; });
                // Пользователь зашёл
                //Console.WriteLine($"User (Name: {user.Username} ID: {user.Id}) joined to a VoiceChannel (Name: {newVoiceState.VoiceChannel.Name} ID: {newVoiceState.VoiceChannel.Id})");
           
            }
            if (oldVoiceState.VoiceChannel != null && oldVoiceState.VoiceChannel.CategoryId == oldVoiceState.VoiceChannel.Guild.GetVoiceChannel(947492715321511976).CategoryId && oldVoiceState.VoiceChannel.Id != 947492715321511976 && oldVoiceState.VoiceChannel.ConnectedUsers.ToArray().Length == 0)
            {
                //Console.WriteLine("aboba");
                oldVoiceState.VoiceChannel.DeleteAsync();
                // Пользователь вышел
               // Console.WriteLine($"User (Name: {user.Username} ID: {user.Id}) left from a VoiceChannel (Name: {oldVoiceState.VoiceChannel.Name} ID: {oldVoiceState.VoiceChannel.Id})");
            }
            //return Task.CompletedTask;
        }

    private async void move_user(SocketGuildUser user, ulong new_channel)
    {
        await user.ModifyAsync(x => { x.ChannelId = new_channel;});
    }
}